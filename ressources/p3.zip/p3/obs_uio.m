function dz = obs_uio(z, v, omega, Y, par)
%OBS_UIO  Polytopic unknown input observer (continuous-time form).
%
%   dz = obs_uio(z, v, omega, Y, par)
%
%   dz/dt = N(ph) z + T B(sh) omega + L(ph) Y,   Xh = z - E Y,
%   N(ph) = sum_k h_k(ph) N_k,  L(ph) = sum_k h_k(ph) L_k,
%   with the scheduling variables evaluated at the estimate Xh.
%   par: fields of uio_model plus Nvert, Lvert (cells of vertex matrices).
Xh = z - par.E*Y;
p = uio_sched(Xh, v, omega);
[~, h] = ts_system(p, par);
N = zeros(3);  L = zeros(3, 2);
for k = 1:numel(h)
    N = N + h(k)*par.Nvert{k};
    L = L + h(k)*par.Lvert{k};
end
x = Xh(1);  y = Xh(2);
B = [x*y, -(1 + x^2), y; 1 + y^2, -x*y, -x; -x*y, -x*y, 0];
dz = N*z + par.T*B*omega(:) + L*Y(:);
end
