function S = lmi_uio_published(Avert, par, alpha, epsy, tol, variant)
%LMI_UIO_PUBLISHED  Vertex LMIs of the published UIO design.
%
%   S = lmi_uio_published(Avert, par, alpha, epsy, tol, variant)
%
%   M_i = [ (1+eta-lam) I - P ,  Q ,  Y_i' , Y_i' ;
%           Q'               , -P ,  0    , 0    ;
%           Y_i              ,  0 , -eps I, 0    ;
%           Y_i              ,  0 ,  0    , -P   ]  < 0 ,  i = 1..r
%
%   variant 'linked'      (default) Q = alpha P, eta = alpha^2 eps fixed,
%                         Y_i = P T A_i - W_i C, minimise lam
%   variant 'independent' P, Q, eps, eta, lam, Y_i all free decision
%                         variables, with the (3,3) block written +eps I,
%                         and W_i recovered a posteriori by
%                         W_i = (P^{-1} Y_i - T A_i)/C, feasibility only
%                         (formulation used before the correction)
%
%   Output: problem code, P, gains K_i, N_i = T A_i - K_i C, L_i = K_i - N_i E,
%   lam, gamma = sqrt(lam)/alpha, worst LMI eigenvalue, largest |K_i(1:2,:)|,
%   continuous decay sigma = min_i lambda_min(-(N_i'P + P N_i), P), phi1.
if nargin < 6, variant = 'linked'; end
yalmip('clear');
r = numel(Avert);  n = 3;  m = 2;  C = par.C;  T = par.T;  E = par.E;
P = sdpvar(n, n, 'symmetric');
F = [P >= tol*eye(n)];
W = cell(r, 1);  Yv = cell(r, 1);  M = cell(r, 1);
switch variant
    case 'linked'
        lam = sdpvar(1, 1);  Q = alpha*P;  eta = alpha^2*epsy;  e3 = -epsy;
        F = [F, lam >= tol];
        for i = 1:r
            W{i} = sdpvar(n, m, 'full');
            Yv{i} = P*T*Avert{i} - W{i}*C;
        end
        obj = lam;
    case 'independent'
        lam = sdpvar(1, 1);  Q = sdpvar(n, n, 'symmetric');
        eta = sdpvar(1, 1);  ep = sdpvar(1, 1);  e3 = ep;
        F = [F, lam >= tol, eta >= tol, ep >= tol];
        for i = 1:r, Yv{i} = sdpvar(n, n, 'full'); end
        obj = [];
end
for i = 1:r
    M{i} = [(1 + eta - lam)*eye(n) - P, Q, Yv{i}.', Yv{i}.';
            Q.', -P, zeros(n), zeros(n);
            Yv{i}, zeros(n), e3*eye(n), zeros(n);
            Yv{i}, zeros(n), zeros(n), -P];
    F = [F, M{i} <= -tol*eye(4*n)];
end
sol = optimize(F, obj, sdpsettings('solver', 'sedumi', 'verbose', 0));
S.variant = variant;  S.problem = sol.problem;  S.info = sol.info;
Pn = value(P);  Pn = (Pn + Pn.')/2;  S.P = Pn;
S.lam = value(lam);  S.gamma = sqrt(max(S.lam, 0))/alpha;
if any(isnan(Pn(:)))
    S.maxEig = NaN;  S.Kup = NaN;  S.sigma = NaN;  S.phi1 = NaN;  S.eigP = nan(1, 3);
    return
end
S.K = cell(r, 1);  S.N = cell(r, 1);  S.L = cell(r, 1);
S.maxEig = -Inf;  S.Kup = 0;  sig = zeros(r, 1);
for i = 1:r
    if strcmp(variant, 'linked')
        Ki = Pn\value(W{i});
    else
        % recovery used with this formulation: Psi = P^{-1} Y_i,
        % W_i = (Psi - T A_i)/C (least squares), K_i = P^{-1} W_i
        Psi = Pn\value(Yv{i});
        Wi = (Psi - T*Avert{i})/C;
        Ki = Pn\Wi;
    end
    Ni = T*Avert{i} - Ki*C;
    S.K{i} = Ki;  S.N{i} = Ni;  S.L{i} = Ki - Ni*E;
    S.maxEig = max(S.maxEig, max(eig((value(M{i}) + value(M{i}).')/2)));
    S.Kup = max(S.Kup, max(max(abs(Ki(1:2, :)))));
    sig(i) = min(real(eig(-(Ni.'*Pn + Pn*Ni), Pn)));
end
S.sigma = min(sig);
ev = eig(Pn);  S.eigP = sort(ev).';
S.phi1 = sqrt(max(ev)/max(min(ev), realmin));
if strcmp(variant, 'independent')
    S.Q = value(Q);  S.eta = value(eta);  S.ep = value(ep);
end
end
