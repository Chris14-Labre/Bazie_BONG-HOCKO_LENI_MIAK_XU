function par = uio_model(pmax)
%UIO_MODEL  Quasi-LPV model of the point kinematics with unknown lateral
%           velocities, in the form used by the published unknown input
%           observer (Chapter 5).
%
%   par = uio_model(pmax)
%
%   dX/dt = A(p) X + B(s) omega + F d,  Y = C X,  X = [x; y; chi],
%   d = [-chi*vx; -chi*vy] (unknown input),
%   A(p) = p1 A1 + ... + p5 A5 with
%   p1 = x vz, p2 = y vz, p3 = vz chi + y wx - x wy, p4 = y wx, p5 = x wy,
%   B(s) = [x y, -(1+x^2), y; 1+y^2, -x y, -x; -x y, -x y, 0].
%   The terms p4 x and p5 y of the third row are cancelled by the third row
%   of B: they do not change the model, only its decomposition.
%   The box is [-pmax, pmax]^5 (default pmax = 5, 32 vertices).
%
%   par contains A0, Acell, pmin, pmax, C, F, E = -F (CF)^+, T = I + E C.
if nargin < 1, pmax = 5; end
par.A0 = zeros(3);
par.Acell = {[0 0 1; 0 0 0; 0 0 0], [0 0 0; 0 0 1; 0 0 0], [0 0 0; 0 0 0; 0 0 1], ...
             [0 0 0; 0 0 0; 1 0 0], [0 0 0; 0 0 0; 0 1 0]};
par.pmin = -pmax*ones(5, 1);
par.pmax =  pmax*ones(5, 1);
par.C = [1 0 0; 0 1 0];
par.F = [1 0; 0 1; 0 0];
par.E = -par.F*pinv(par.C*par.F);
par.T = eye(3) + par.E*par.C;
end
