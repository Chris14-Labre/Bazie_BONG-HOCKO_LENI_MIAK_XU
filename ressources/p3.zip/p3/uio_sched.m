function p = uio_sched(X, v, omega)
%UIO_SCHED  Scheduling variables of the UIO model (see uio_model).
x = X(1); y = X(2); chi = X(3);
p = [x*v(3); y*v(3); v(3)*chi + y*omega(1) - x*omega(2); y*omega(1); x*omega(2)];
end
