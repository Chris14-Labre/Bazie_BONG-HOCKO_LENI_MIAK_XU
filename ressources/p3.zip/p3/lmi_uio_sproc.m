function S = lmi_uio_sproc(Avert, par, alpha, tol, timeDomain)
%LMI_UIO_SPROC  Sufficient conditions for the UIO error with a sector-bounded
%               residual, |Delta| <= alpha |e|, by the S-procedure.
%
%   S = lmi_uio_sproc(Avert, par, alpha, tol, timeDomain)
%
%   'ct' : de/dt = N_i e + Delta,
%          [N_i'P + P N_i + tau alpha^2 I + tol I,  P ; P, -tau I] <= 0
%   'dt' : e_{k+1} = N_i e_k + Delta_k,
%          [-P + tau alpha^2 I + tol I, 0, N_i'P ; 0, -tau I, P ; P N_i, P, -P] <= 0
%   with P N_i = P T A_i - W_i C, W_i = P K_i, P >= I, tau >= 0.
%   Output: feasibility flag and solver code.
yalmip('clear');
r = numel(Avert);  n = 3;  m = 2;  C = par.C;  T = par.T;
P = sdpvar(n, n, 'symmetric');  tau = sdpvar(1, 1);
F = [P >= eye(n), tau >= 0];
Mc = cell(r, 1);
for i = 1:r
    W = sdpvar(n, m, 'full');
    PN = P*T*Avert{i} - W*C;
    if strcmp(timeDomain, 'ct')
        M = [PN.' + PN + tau*alpha^2*eye(n) + tol*eye(n), P; P, -tau*eye(n)];
    else
        M = [-P + tau*alpha^2*eye(n) + tol*eye(n), zeros(n), PN.';
             zeros(n), -tau*eye(n), P;
             PN, P, -P];
    end
    F = [F, M <= 0];  Mc{i} = M;
end
sol = optimize(F, [], sdpsettings('solver', 'sedumi', 'verbose', 0));
S.problem = sol.problem;  S.info = sol.info;
S.feasible = (sol.problem == 0);
S.maxEig = -Inf;
for i = 1:r
    Mi = value(Mc{i});
    if any(isnan(Mi(:))), S.maxEig = NaN; break, end
    S.maxEig = max(S.maxEig, max(eig((Mi + Mi.')/2)));
end
% a posteriori check of the computed point
S.feasible = S.feasible && ~isnan(S.maxEig) && S.maxEig <= 1e-8 ...
             && all(eig(value(P)) >= 1 - 1e-6);
end
